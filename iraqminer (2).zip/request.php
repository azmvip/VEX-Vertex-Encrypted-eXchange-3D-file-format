<?php
define('DATA_DIR', __DIR__ . '/data/');
define('ENCRYPTION_KEY', 'IraqMiner@2025!SecureKey#XkZ9pLmQ7rTvWbNj4sDcF1eHuYoAi6g');
define('ENCRYPTION_CIPHER', 'AES-256-CBC');

header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['ok'=>false,'msg'=>'Method Not Allowed']);exit;}

function enc(string $d):string{$iv=random_bytes(openssl_cipher_iv_length(ENCRYPTION_CIPHER));return base64_encode($iv.'::'.openssl_encrypt($d,ENCRYPTION_CIPHER,ENCRYPTION_KEY,0,$iv));}
function dec(string $d):string{$r=base64_decode($d);if(strpos($r,'::')===false)return $d;[$iv,$e]=explode('::',$r,2);$x=openssl_decrypt($e,ENCRYPTION_CIPHER,ENCRYPTION_KEY,0,$iv);return $x===false?'':$x;}
function rj(string $f):array{$p=DATA_DIR.$f;if(!file_exists($p))return[];$r=file_get_contents($p);if(!$r)return[];$d=json_decode(dec(trim($r)),true);return is_array($d)?$d:[];}
function wj(string $f,array $d):bool{if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0755,true);return file_put_contents(DATA_DIR.$f,enc(json_encode($d,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)),LOCK_EX)!==false;}
function s(string $v):string{return htmlspecialchars(strip_tags(trim($v)),ENT_QUOTES,'UTF-8');}
function gid(array $a):int{return empty($a)?1:max(array_column($a,'id'))+1;}

$mod_name=s($_POST['mod_name']??''); $mod_type=s($_POST['mod_type']??'');
$desc=s($_POST['description']??''); $file_url=s($_POST['file_url']??'');
$img_url=s($_POST['image_url']??''); $sname=s($_POST['submitter_name']??'');
$sage=s($_POST['submitter_age']??''); $semail=s($_POST['submitter_email']??'');

$errors=[];
if(!$mod_name) $errors[]='اسم المود مطلوب';
if(!$mod_type) $errors[]='نوع المود مطلوب';
if(!$file_url) $errors[]='رابط الملف مطلوب';
if(!$sname)    $errors[]='اسمك مطلوب';
if(!$semail||!filter_var($semail,FILTER_VALIDATE_EMAIL)) $errors[]='بريد إلكتروني صالح مطلوب';
if(!empty($errors)){echo json_encode(['ok'=>false,'msg'=>implode(' | ',$errors)]);exit;}

$ip=hash('sha256',$_SERVER['HTTP_X_FORWARDED_FOR']??$_SERVER['REMOTE_ADDR']??'');
$tmp=sys_get_temp_dir().'/iqreq_'.$ip.'_'.date('Ymd');
$cnt=file_exists($tmp)?(int)file_get_contents($tmp):0;
if($cnt>=5){echo json_encode(['ok'=>false,'msg'=>'تجاوزت الحد اليومي (5 طلبات)']);exit;}
file_put_contents($tmp,$cnt+1);

$reqs=rj('requests.json');
$reqs[]=['id'=>gid($reqs),'mod_name'=>$mod_name,'mod_type'=>$mod_type,'description'=>$desc,'file_url'=>$file_url,'image_url'=>$img_url,'submitter_name'=>$sname,'submitter_age'=>$sage,'submitter_email'=>$semail,'status'=>'pending','submitted_at'=>date('Y-m-d H:i:s'),'ip'=>$ip];
echo wj('requests.json',$reqs)
    ? json_encode(['ok'=>true,'msg'=>'تم إرسال طلبك! سيراجعه الفريق قريباً.'])
    : json_encode(['ok'=>false,'msg'=>'خطأ في الحفظ، حاول لاحقاً']);

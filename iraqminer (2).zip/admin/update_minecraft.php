<?php
require_once __DIR__ . '/config.php';
require_admin();
$info = read_encrypted_json('minecraft.json');
$msg = $err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $ver=$_POST['version']??''; $desc=$_POST['description']??''; $img=$_POST['image']??''; $dlurl=$_POST['download_url']??'';
    $plats=array_map('sanitize',(array)($_POST['platforms']??[]));
    if(!trim($ver)||!trim($dlurl)){$err='الإصدار والرابط مطلوبان';}
    else{ write_encrypted_json('minecraft.json',['version'=>sanitize($ver),'description'=>sanitize($desc),'image'=>sanitize($img),'platforms'=>$plats,'download_url'=>sanitize($dlurl)]); $info=read_encrypted_json('minecraft.json'); $msg='تم التحديث'; }
}
$all=['Android','iOS','Windows','PlayStation','Xbox','Nintendo Switch'];
?><!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ماينكرافت | Iraqminer</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<?php include '_sidebar.php'; ?>
<main class="main">
  <div class="topbar"><h1>معلومات <span>ماينكرافت</span></h1></div>
  <?php if($msg): ?><div class="al al-ok"><i class="fas fa-check-circle"></i> <?= e($msg) ?></div><?php endif; ?>
  <?php if($err): ?><div class="al al-err"><i class="fas fa-times-circle"></i> <?= e($err) ?></div><?php endif; ?>
  <div class="card"><div class="ct"><i class="fas fa-cube"></i> بيانات ماينكرافت بيدروك</div>
  <form method="POST">
    <div class="fg-grid">
      <div class="fg"><label>رقم الإصدار *</label><input type="text" name="version" value="<?= e($info['version']??'') ?>" placeholder="1.21.0" required></div>
      <div class="fg"><label>رابط التنزيل *</label><input type="url" name="download_url" value="<?= e($info['download_url']??'') ?>" placeholder="https://..." required></div>
      <div class="fg"><label>رابط الصورة</label><input type="text" name="image" value="<?= e($info['image']??'') ?>" placeholder="رابط الصورة"></div>
    </div>
    <div class="fg"><label>الوصف</label><textarea name="description" rows="3"><?= e($info['description']??'') ?></textarea></div>
    <div class="fg"><label>المنصات المدعومة</label>
      <div class="df g3 fw">
        <?php foreach($all as $p): ?>
        <div class="fcheck"><input type="checkbox" name="platforms[]" id="pl_<?= e($p) ?>" value="<?= e($p) ?>" <?= in_array($p,(array)($info['platforms']??[]))?'checked':'' ?>><label for="pl_<?= e($p) ?>"><?= e($p) ?></label></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php if(!empty($info['image'])): ?>
    <div style="margin-bottom:16px"><p style="color:var(--muted);font-size:.8rem;margin-bottom:8px">الصورة الحالية:</p><img src="<?= e($info['image']) ?>" style="max-width:180px;border-radius:10px;border:1px solid var(--border)" alt=""></div>
    <?php endif; ?>
    <button type="submit" class="btn btn-p"><i class="fas fa-save"></i> حفظ</button>
  </form></div>
  <div class="card"><div class="ct"><i class="fas fa-eye"></i> الحالة الحالية</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px">
      <div style="background:rgba(0,230,118,.07);border:1px solid var(--border);border-radius:11px;padding:14px"><div style="color:var(--muted);font-size:.72rem;margin-bottom:3px">الإصدار</div><div style="font-size:1.4rem;font-weight:700;color:var(--accent)"><?= e($info['version']??'–') ?></div></div>
      <?php foreach((array)($info['platforms']??[]) as $p): ?>
      <div style="background:rgba(41,182,246,.07);border:1px solid rgba(41,182,246,.2);border-radius:11px;padding:14px"><div style="color:var(--muted);font-size:.72rem;margin-bottom:3px">منصة</div><div style="font-weight:600;color:var(--info)"><?= e($p) ?></div></div>
      <?php endforeach; ?>
    </div>
  </div>
</main></div></body></html>

<?php
/**
 * Iraqminer — Admin Core Config
 *
 * ZERO PHP sessions. Auth uses a token stored in a plain setcookie() call.
 * This bypasses every InfinityFree/Cloudflare session-cookie interference.
 */

define('ENCRYPTION_KEY',  'IraqMiner@2025!SecureKey#XkZ9pLmQ7rTvWbNj4sDcF1eHuYoAi6g');
define('ENCRYPTION_CIPHER', 'AES-256-CBC');
define('DATA_DIR',        __DIR__ . '/../data/');
define('TOKEN_COOKIE',    'iqm_auth');
define('TOKEN_LIFETIME',  7200); // seconds

// ── Encryption ────────────────────────────────────────────────────────────────

function encrypt_data(string $data): string {
    $ivLen = openssl_cipher_iv_length(ENCRYPTION_CIPHER);
    $iv    = random_bytes($ivLen);
    $enc   = openssl_encrypt($data, ENCRYPTION_CIPHER, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $enc);
}

function decrypt_data(string $data): string {
    $raw = base64_decode($data);
    if (strpos($raw, '::') === false) return $data;
    [$iv, $enc] = explode('::', $raw, 2);
    $dec = openssl_decrypt($enc, ENCRYPTION_CIPHER, ENCRYPTION_KEY, 0, $iv);
    return $dec === false ? '' : $dec;
}

function read_encrypted_json(string $filename): array {
    $path = DATA_DIR . $filename;
    if (!file_exists($path)) return [];
    $raw = file_get_contents($path);
    if ($raw === false || trim($raw) === '') return [];
    $dec = decrypt_data(trim($raw));
    if ($dec === '') return [];
    $arr = json_decode($dec, true);
    return is_array($arr) ? $arr : [];
}

function write_encrypted_json(string $filename, array $data): bool {
    if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0755, true);
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(DATA_DIR . $filename, encrypt_data($json), LOCK_EX) !== false;
}

// ── Token-based auth (NO sessions) ───────────────────────────────────────────

function create_auth_token(int $admin_id): string {
    $token  = bin2hex(random_bytes(32));
    $tokens = read_encrypted_json('tokens.json');
    // Prune expired
    $tokens = array_values(array_filter($tokens, fn($t) => ($t['expires'] ?? 0) > time()));
    $tokens[] = [
        'token'    => $token,
        'admin_id' => $admin_id,
        'expires'  => time() + TOKEN_LIFETIME,
        'ip'       => hash('sha256', $_SERVER['REMOTE_ADDR'] ?? ''),
    ];
    write_encrypted_json('tokens.json', $tokens);
    return $token;
}

function set_auth_cookie(string $token): void {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    // setcookie with array params (PHP 7.3+)
    setcookie(TOKEN_COOKIE, $token, [
        'expires'  => time() + TOKEN_LIFETIME,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function clear_auth_cookie(): void {
    setcookie(TOKEN_COOKIE, '', [
        'expires'  => time() - 86400,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    // Revoke token from storage
    $raw = $_COOKIE[TOKEN_COOKIE] ?? '';
    if ($raw) {
        $tokens = read_encrypted_json('tokens.json');
        $tokens = array_values(array_filter($tokens, fn($t) => $t['token'] !== $raw));
        write_encrypted_json('tokens.json', $tokens);
    }
}

function get_current_admin(): ?array {
    $raw = $_COOKIE[TOKEN_COOKIE] ?? '';
    if (!$raw) return null;
    $tokens = read_encrypted_json('tokens.json');
    $admin_id = null;
    foreach ($tokens as $t) {
        if ($t['token'] === $raw && ($t['expires'] ?? 0) > time()) {
            $admin_id = $t['admin_id'];
            break;
        }
    }
    if (!$admin_id) return null;
    $admins = read_encrypted_json('admins.json');
    foreach ($admins as $a) {
        if ($a['id'] == $admin_id) return $a;
    }
    return null;
}

function require_admin(): void {
    if (!get_current_admin()) {
        header('Location: index.php?err=auth');
        exit;
    }
}

function is_main_admin(): bool {
    $a = get_current_admin();
    return $a !== null && ($a['role'] ?? '') === 'main';
}

function has_permission(string $perm): bool {
    $a = get_current_admin();
    if (!$a) return false;
    if ($a['role'] === 'main') return true;
    $perms = (array)($a['permissions'] ?? []);
    return in_array('all', $perms, true) || in_array($perm, $perms, true);
}

// ── Data helpers ──────────────────────────────────────────────────────────────

function generate_id(array $arr): int {
    if (empty($arr)) return 1;
    return max(array_column($arr, 'id')) + 1;
}

function sanitize(string $s): string {
    return htmlspecialchars(strip_tags(trim($s)), ENT_QUOTES, 'UTF-8');
}

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function conv_drive(string $url): string {
    $url = trim($url);
    if (empty($url)) return '';
    if (strpos($url, 'drive.google.com/uc') !== false) return $url;
    if (preg_match('#/file/d/([a-zA-Z0-9_\-]+)#', $url, $m))
        return 'https://drive.google.com/uc?export=download&id=' . $m[1];
    if (preg_match('#[?&]id=([a-zA-Z0-9_\-]+)#', $url, $m))
        return 'https://drive.google.com/uc?export=download&id=' . $m[1];
    return $url;
}

// ── Initialise data files ─────────────────────────────────────────────────────

function init_data(): void {
    if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0755, true);

    // Admins
    $admins = read_encrypted_json('admins.json');
    if (empty($admins)) {
        write_encrypted_json('admins.json', [[
            'id'          => 1,
            'username'    => 'iraqmineradmin',
            'password'    => password_hash('Js7@pQk!9tXz#2Lm', PASSWORD_BCRYPT, ['cost' => 12]),
            'role'        => 'main',
            'permissions' => ['all'],
            'created_at'  => date('Y-m-d H:i:s'),
        ]]);
    }

    // Other defaults
    $defaults = [
        'tokens.json'    => [],
        'mods.json'      => [],
        'requests.json'  => [],
        'stats.json'     => ['visitors'=>['total_pageviews'=>0,'unique_visitors'=>0,'daily'=>[]],'downloads'=>['total'=>0,'per_mod'=>[]]],
        'minecraft.json' => ['version'=>'1.21.0','description'=>'أحدث إصدار من ماينكرافت بيدروك','image'=>'','platforms'=>['Android','iOS','Windows'],'download_url'=>'https://www.minecraft.net/ar-sa/download'],
        'settings.json'  => ['site_name'=>'Iraqminer','per_page'=>12],
    ];
    foreach ($defaults as $file => $val) {
        if (!file_exists(DATA_DIR . $file)) write_encrypted_json($file, $val);
    }
}

init_data();

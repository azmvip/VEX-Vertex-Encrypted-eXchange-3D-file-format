<?php
/**
 * Iraqminer Admin — Login (session-free, token-based)
 */
require_once __DIR__ . '/config.php';

// Already logged in?
if (get_current_admin()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        $error = 'يرجى إدخال اسم المستخدم وكلمة المرور';
    } else {
        $admins = read_encrypted_json('admins.json');
        $found  = null;
        foreach ($admins as $admin) {
            if ($admin['username'] === $username && password_verify($password, $admin['password'])) {
                $found = $admin;
                break;
            }
        }

        if ($found) {
            $token = create_auth_token((int)$found['id']);
            set_auth_cookie($token);
            // Redirect — cookie will be sent on this response
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'اسم المستخدم أو كلمة المرور غلط';
        }
    }
}

$err_param = $_GET['err'] ?? '';
?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>تسجيل الدخول | Iraqminer</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="style.css">
<style>
body{display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;background:var(--bg)}
.login-wrap{width:100%;max-width:420px}
.login-card{background:rgba(22,28,38,.95);border:1px solid rgba(0,230,118,.2);border-radius:20px;padding:48px 40px;backdrop-filter:blur(24px);box-shadow:0 0 60px rgba(0,230,118,.07)}
.login-logo{text-align:center;margin-bottom:36px}
.logo-box{width:72px;height:72px;background:linear-gradient(135deg,#00e676,#00c853);border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:1.9rem;font-weight:900;color:#0a0e14;margin:0 auto 14px;font-family:'Cairo',sans-serif;box-shadow:0 0 30px rgba(0,230,118,.35)}
.login-logo h1{color:#00e676;font-size:1.45rem;margin:0 0 4px}
.login-logo p{color:#8a9bb0;font-size:.82rem;margin:0}
.fg{margin-bottom:20px;position:relative}
.fg label{display:block;font-size:.83rem;color:#8a9bb0;margin-bottom:6px;font-weight:600}
.fg input{width:100%;padding:13px 46px 13px 16px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;color:#e2e8f0;font-family:'Cairo',sans-serif;font-size:.95rem;transition:.25s;box-sizing:border-box}
.fg input:focus{border-color:#00e676;outline:none;background:rgba(0,230,118,.05)}
.fg .ico{position:absolute;right:15px;bottom:14px;color:#8a9bb0;pointer-events:none;font-size:.9rem}
.btn-login{width:100%;padding:14px;background:linear-gradient(135deg,#00e676,#00c853);border:none;border-radius:10px;color:#0a0e14;font-family:'Cairo',sans-serif;font-size:1rem;font-weight:700;cursor:pointer;transition:.25s;letter-spacing:.3px}
.btn-login:hover{transform:translateY(-2px);box-shadow:0 6px 22px rgba(0,230,118,.4)}
.btn-login:active{transform:translateY(0)}
.alert{border-radius:10px;padding:12px 16px;margin-bottom:20px;font-size:.87rem;display:flex;align-items:center;gap:10px;line-height:1.5}
.alert-err{background:rgba(239,83,80,.1);border:1px solid rgba(239,83,80,.3);color:#ef5350}
.alert-warn{background:rgba(255,167,38,.1);border:1px solid rgba(255,167,38,.3);color:#ffa726}
.back{text-align:center;margin-top:20px}
.back a{color:#8a9bb0;font-size:.83rem;text-decoration:none;transition:.2s}
.back a:hover{color:#00e676}
.divider{border:none;border-top:1px solid rgba(255,255,255,.06);margin:22px 0}
.hint{background:rgba(0,230,118,.05);border:1px solid rgba(0,230,118,.15);border-radius:10px;padding:14px 16px;font-size:.8rem;color:#8a9bb0;line-height:1.8}
.hint strong{color:#00e676}
</style>
</head>
<body>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo">
      <div class="logo-box">IM</div>
      <h1>Iraqminer</h1>
      <p>لوحة تحكم المنصة</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-err"><i class="fas fa-exclamation-circle"></i> <?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($err_param === 'auth'): ?>
    <div class="alert alert-warn"><i class="fas fa-lock"></i> انتهت الجلسة، يرجى تسجيل الدخول مرة أخرى</div>
    <?php endif; ?>

    <form method="POST" autocomplete="on">
      <div class="fg">
        <label for="u">اسم المستخدم</label>
        <input type="text" id="u" name="username" placeholder="أدخل اسم المستخدم" required autocomplete="username">
        <i class="fas fa-user ico"></i>
      </div>
      <div class="fg">
        <label for="p">كلمة المرور</label>
        <input type="password" id="p" name="password" placeholder="أدخل كلمة المرور" required autocomplete="current-password">
        <i class="fas fa-lock ico"></i>
      </div>
      <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i>&nbsp; دخول</button>
    </form>

    <hr class="divider">

    <div class="hint">
      <strong><i class="fas fa-info-circle"></i> ملاحظة تقنية:</strong><br>
      هذا النظام لا يستخدم PHP Sessions بل <strong>Token مشفّر</strong> في كوكي مباشر — يعمل في جميع المتصفحات.
    </div>

    <div class="back"><a href="../index.php"><i class="fas fa-arrow-right"></i> العودة للموقع</a></div>
  </div>
</div>
</body>
</html>

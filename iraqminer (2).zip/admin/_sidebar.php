<?php
// Reusable sidebar – included by all admin pages
$_admin   = get_current_admin();
$_is_main = is_main_admin();
$_reqs    = read_encrypted_json('requests.json');
$_pending = count(array_filter($_reqs, fn($r)=>($r['status']??'pending')==='pending'));
$_cur     = basename($_SERVER['PHP_SELF'],'');
?>
<aside class="sidebar">
  <div class="s-logo">
    <div class="li">IM</div>
    <div><h2>Iraqminer</h2><p>لوحة التحكم</p></div>
  </div>
  <nav class="s-nav">
    <div class="s-sec">الرئيسية</div>
    <a href="dashboard.php"        class="s-item <?= $_cur==='dashboard.php'?'on':'' ?>"><i class="fas fa-th-large"></i> لوحة التحكم</a>
    <a href="../index.php"         class="s-item" target="_blank"><i class="fas fa-globe"></i> زيارة الموقع</a>
    <div class="s-sec">المحتوى</div>
    <a href="manage_mods.php"      class="s-item <?= $_cur==='manage_mods.php'?'on':'' ?>"><i class="fas fa-puzzle-piece"></i> الموديات</a>
    <a href="manage_requests.php"  class="s-item <?= $_cur==='manage_requests.php'?'on':'' ?>"><i class="fas fa-inbox"></i> الطلبات <?php if($_pending>0): ?><span class="badge-notif"><?= $_pending ?></span><?php endif; ?></a>
    <a href="update_minecraft.php" class="s-item <?= $_cur==='update_minecraft.php'?'on':'' ?>"><i class="fas fa-cube"></i> ماينكرافت</a>
    <?php if($_is_main): ?>
    <div class="s-sec">الإدارة</div>
    <a href="manage_admins.php"    class="s-item <?= $_cur==='manage_admins.php'?'on':'' ?>"><i class="fas fa-users-cog"></i> المشرفون</a>
    <?php endif; ?>
  </nav>
  <div class="s-foot">
    <div class="s-user">
      <div class="s-av"><?= strtoupper(mb_substr($_admin['username'],0,1,'UTF-8')) ?></div>
      <div><div class="s-name"><?= e($_admin['username']) ?></div><div class="s-role"><?= $_is_main?'مشرف رئيسي':'مشرف فرعي' ?></div></div>
    </div>
    <a href="logout.php" class="btn-out"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
  </div>
</aside>

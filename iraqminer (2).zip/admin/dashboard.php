<?php
require_once __DIR__ . '/config.php';
require_admin();
$admin   = get_current_admin();
$is_main = is_main_admin();
$mods    = read_encrypted_json('mods.json');
$reqs    = read_encrypted_json('requests.json');
$stats   = read_encrypted_json('stats.json');
$admins  = read_encrypted_json('admins.json');
$pending = array_values(array_filter($reqs, fn($r) => ($r['status'] ?? 'pending') === 'pending'));
$per_mod = $stats['downloads']['per_mod'] ?? [];
arsort($per_mod);
$top = [];
foreach (array_slice($per_mod, 0, 5, true) as $mid => $cnt)
    foreach ($mods as $m) if ((string)$m['id'] === (string)$mid) { $top[] = ['name'=>$m['name'],'type'=>$m['type']??'','dl'=>$cnt]; break; }
$last7 = [];
for ($i = 6; $i >= 0; $i--) { $d = date('Y-m-d', strtotime("-{$i} days")); $last7[$d] = $stats['visitors']['daily'][$d] ?? ['pageviews'=>0,'uniques'=>0]; }
?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>لوحة التحكم | Iraqminer</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<?php include '_sidebar.php'; ?>
<main class="main">
  <div class="topbar"><h1>أهلاً، <span><?= e($admin['username']) ?></span> 👋</h1><a href="manage_mods.php?action=add" class="btn btn-p"><i class="fas fa-plus"></i> إضافة مود</a></div>

  <div class="stat-g">
    <div class="stat-c"><div class="si g"><i class="fas fa-puzzle-piece"></i></div><div class="sv"><div class="val"><?= count($mods) ?></div><div class="lbl">الموديات</div></div></div>
    <div class="stat-c"><div class="si o"><i class="fas fa-inbox"></i></div><div class="sv"><div class="val"><?= count($pending) ?></div><div class="lbl">طلبات معلّقة</div></div></div>
    <?php if($is_main): ?>
    <div class="stat-c"><div class="si b"><i class="fas fa-eye"></i></div><div class="sv"><div class="val"><?= number_format($stats['visitors']['unique_visitors']??0) ?></div><div class="lbl">زوار فريدون</div></div></div>
    <div class="stat-c"><div class="si g"><i class="fas fa-download"></i></div><div class="sv"><div class="val"><?= number_format($stats['downloads']['total']??0) ?></div><div class="lbl">تنزيلات</div></div></div>
    <div class="stat-c"><div class="si b"><i class="fas fa-chart-line"></i></div><div class="sv"><div class="val"><?= number_format($stats['visitors']['total_pageviews']??0) ?></div><div class="lbl">مشاهدات</div></div></div>
    <div class="stat-c"><div class="si r"><i class="fas fa-users-cog"></i></div><div class="sv"><div class="val"><?= count($admins) ?></div><div class="lbl">المشرفون</div></div></div>
    <?php endif; ?>
  </div>

  <?php if(!empty($pending)): ?>
  <div class="card"><div class="ct"><i class="fas fa-inbox"></i> طلبات معلّقة (<?= count($pending) ?>)</div>
  <div class="tw"><table><tr><th>المود</th><th>النوع</th><th>المقدّم</th><th>التاريخ</th><th>إجراء</th></tr>
  <?php foreach(array_slice($pending,0,5) as $r): ?><tr>
    <td><?= e($r['mod_name']??'') ?></td><td><span class="bg bg-b"><?= e($r['mod_type']??'') ?></span></td>
    <td><?= e($r['submitter_name']??'') ?></td><td><?= e(substr($r['submitted_at']??'',0,10)) ?></td>
    <td><a href="manage_requests.php" class="btn btn-i btn-sm">مراجعة</a></td>
  </tr><?php endforeach; ?>
  </table></div>
  <?php if(count($pending)>5): ?><p style="margin-top:8px;font-size:.8rem;color:var(--muted)">و <?= count($pending)-5 ?> أخرى… <a href="manage_requests.php">عرض الكل</a></p><?php endif; ?>
  </div><?php endif; ?>

  <?php if($is_main && !empty($top)): ?>
  <div class="card"><div class="ct"><i class="fas fa-trophy"></i> أكثر الموديات تنزيلاً</div>
  <div class="tw"><table><tr><th>#</th><th>المود</th><th>النوع</th><th>تنزيلات</th></tr>
  <?php foreach($top as $i=>$m): ?><tr><td><?= $i+1 ?></td><td><?= e($m['name']) ?></td><td><span class="bg bg-g"><?= e($m['type']) ?></span></td><td><strong style="color:var(--accent)"><?= number_format($m['dl']) ?></strong></td></tr><?php endforeach; ?>
  </table></div></div>
  <?php endif; ?>

  <?php if($is_main): ?>
  <div class="card"><div class="ct"><i class="fas fa-calendar-week"></i> الزوار – آخر 7 أيام</div>
  <div class="tw"><table><tr><th>التاريخ</th><th>مشاهدات</th><th>زوار فريدون</th></tr>
  <?php foreach($last7 as $day=>$d): ?><tr><td><?= e($day) ?></td><td><?= number_format($d['pageviews']) ?></td><td><?= number_format($d['uniques']) ?></td></tr><?php endforeach; ?>
  </table></div></div>
  <?php endif; ?>

  <div class="card"><div class="ct"><i class="fas fa-puzzle-piece"></i> آخر الموديات</div>
  <?php $recent=array_slice(array_reverse($mods),0,6); if(empty($recent)): ?>
  <div class="empty"><i class="fas fa-puzzle-piece"></i><p>لا توجد موديات – <a href="manage_mods.php?action=add">أضف أول مود!</a></p></div>
  <?php else: ?><div class="tw"><table><tr><th>الصورة</th><th>الاسم</th><th>النوع</th><th>التاريخ</th><th>إجراءات</th></tr>
  <?php foreach($recent as $m): ?><tr>
    <td><?php if(!empty($m['image'])): ?><img src="<?= e($m['image']) ?>" class="mthumb" alt=""><?php else: ?><div class="mthumb df ac" style="justify-content:center;background:rgba(0,230,118,.08)"><i class="fas fa-puzzle-piece" style="color:var(--accent)"></i></div><?php endif; ?></td>
    <td><strong><?= e($m['name']??'') ?></strong></td><td><span class="bg bg-g"><?= e($m['type']??'') ?></span></td>
    <td><?= e(substr($m['created_at']??'',0,10)) ?></td>
    <td class="df g2"><a href="manage_mods.php?action=edit&id=<?= $m['id'] ?>" class="btn btn-i btn-sm"><i class="fas fa-edit"></i></a><a href="manage_mods.php?action=delete&id=<?= $m['id'] ?>" class="btn btn-d btn-sm" onclick="return confirm('حذف؟')"><i class="fas fa-trash"></i></a></td>
  </tr><?php endforeach; ?>
  </table></div><a href="manage_mods.php" class="btn btn-p mt3"><i class="fas fa-list"></i> كل الموديات</a><?php endif; ?>
  </div>
</main></div></body></html>

<?php
require_once __DIR__ . '/config.php';
require_admin();
$requests = read_encrypted_json('requests.json');
$mods     = read_encrypted_json('mods.json');
$msg = '';
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$req_id = (int)($_POST['req_id'] ?? $_GET['id'] ?? 0);

if ($action==='approve' && $req_id) {
    $t=$ti=null; foreach($requests as $i=>$r){ if($r['id']==$req_id){$t=$r;$ti=$i;break;} }
    if($t){ $mods[]=['id'=>generate_id($mods),'name'=>$t['mod_name']??'','type'=>$t['mod_type']??'','version'=>'','description'=>$t['description']??'','author'=>$t['submitter_name']??'','tags'=>'','image'=>conv_drive($t['image_url']??''),'download'=>conv_drive($t['file_url']??''),'featured'=>0,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),'from_request'=>true];
        write_encrypted_json('mods.json',$mods); $requests[$ti]['status']='approved'; $requests[$ti]['approved_at']=date('Y-m-d H:i:s'); write_encrypted_json('requests.json',$requests); $msg='تم قبول الطلب وإضافة المود'; }
}
if ($action==='reject' && $req_id) {
    foreach($requests as $i=>$r){ if($r['id']==$req_id){$requests[$i]['status']='rejected';$requests[$i]['rejected_at']=date('Y-m-d H:i:s');break;} }
    write_encrypted_json('requests.json',$requests); $msg='تم رفض الطلب';
}
if ($action==='delete' && $req_id) {
    $requests=array_values(array_filter($requests,fn($r)=>$r['id']!=$req_id)); write_encrypted_json('requests.json',$requests); header('Location: manage_requests.php?ok=deleted'); exit;
}
$requests=read_encrypted_json('requests.json');
$filter=$_GET['filter']??'pending';
$shown=array_reverse(array_values(array_filter($requests,fn($r)=>$filter==='all'||($r['status']??'pending')===$filter)));
if(($_GET['ok']??'')==='deleted') $msg='تم الحذف';
?><!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>إدارة الطلبات | Iraqminer</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<?php include '_sidebar.php'; ?>
<main class="main">
  <div class="topbar"><h1>طلبات <span>الرفع</span></h1></div>
  <?php if($msg): ?><div class="al al-ok"><i class="fas fa-check-circle"></i> <?= e($msg) ?></div><?php endif; ?>
  <div class="df g2 fw" style="margin-bottom:18px">
    <?php foreach(['pending'=>'معلّقة','approved'=>'مقبولة','rejected'=>'مرفوضة','all'=>'الكل'] as $f=>$l): ?>
    <a href="?filter=<?= $f ?>" class="btn <?= $filter===$f?'btn-p':'btn-i' ?> btn-sm"><?= $l ?></a>
    <?php endforeach; ?>
  </div>
  <div class="card"><div class="ct"><i class="fas fa-inbox"></i> الطلبات (<?= count($shown) ?>)</div>
  <?php if(empty($shown)): ?><div class="empty"><i class="fas fa-inbox"></i><p>لا توجد طلبات</p></div>
  <?php else: foreach($shown as $req): $s=$req['status']??'pending'; ?>
  <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:13px;padding:18px;margin-bottom:14px">
    <div class="df ac g3 fw" style="margin-bottom:10px">
      <h3 style="margin:0;font-size:.98rem"><?= e($req['mod_name']??'') ?></h3>
      <span class="bg bg-b"><?= e($req['mod_type']??'') ?></span>
      <?php if($s==='pending'): ?><span class="bg bg-o">معلّق</span><?php elseif($s==='approved'): ?><span class="bg bg-g">مقبول</span><?php else: ?><span class="bg bg-r">مرفوض</span><?php endif; ?>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:6px;font-size:.8rem;color:var(--muted);margin-bottom:10px">
      <span><i class="fas fa-user"></i> <?= e($req['submitter_name']??'') ?></span>
      <span><i class="fas fa-envelope"></i> <?= e($req['submitter_email']??'') ?></span>
      <span><i class="fas fa-calendar"></i> <?= e(substr($req['submitted_at']??'',0,10)) ?></span>
    </div>
    <?php if(!empty($req['description'])): ?><p style="font-size:.85rem;line-height:1.6;color:var(--text);margin-bottom:10px"><?= e($req['description']) ?></p><?php endif; ?>
    <div class="df g2 fw" style="margin-bottom:10px">
      <?php if(!empty($req['file_url'])): ?><a href="<?= e($req['file_url']) ?>" target="_blank" class="btn btn-i btn-sm"><i class="fas fa-link"></i> رابط الملف</a><?php endif; ?>
      <?php if(!empty($req['image_url'])): ?><a href="<?= e($req['image_url']) ?>" target="_blank" class="btn btn-i btn-sm"><i class="fas fa-image"></i> رابط الصورة</a><?php endif; ?>
    </div>
    <?php if($s==='pending'): ?>
    <div class="df g2 fw">
      <form method="POST" style="display:inline"><input type="hidden" name="req_id" value="<?= $req['id'] ?>"><input type="hidden" name="action" value="approve"><button type="submit" class="btn btn-p btn-sm"><i class="fas fa-check"></i> قبول وإضافة</button></form>
      <form method="POST" style="display:inline"><input type="hidden" name="req_id" value="<?= $req['id'] ?>"><input type="hidden" name="action" value="reject"><button type="submit" class="btn btn-w btn-sm" onclick="return confirm('رفض؟')"><i class="fas fa-times"></i> رفض</button></form>
      <a href="?action=delete&id=<?= $req['id'] ?>" class="btn btn-d btn-sm" onclick="return confirm('حذف نهائي؟')"><i class="fas fa-trash"></i></a>
    </div>
    <?php else: ?><a href="?action=delete&id=<?= $req['id'] ?>" class="btn btn-d btn-sm" onclick="return confirm('حذف؟')"><i class="fas fa-trash"></i> حذف</a><?php endif; ?>
  </div>
  <?php endforeach; endif; ?>
  </div>
</main></div></body></html>

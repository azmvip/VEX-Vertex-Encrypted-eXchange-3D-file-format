<?php
require_once __DIR__ . '/config.php';
clear_auth_cookie();
header('Location: index.php');
exit;

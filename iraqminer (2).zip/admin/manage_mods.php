<?php
require_once __DIR__ . '/config.php';
require_admin();
$mods   = read_encrypted_json('mods.json');
$action = $_GET['action'] ?? 'list';
$msg = $err = '';

if ($action==='delete' && isset($_GET['id'])) {
    $mods = array_values(array_filter($mods, fn($m)=>$m['id']!==(int)$_GET['id']));
    write_encrypted_json('mods.json', $mods);
    header('Location: manage_mods.php?ok=deleted'); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id   = (int)($_POST['id']??0);
    $name = sanitize($_POST['name']??'');
    $type = sanitize($_POST['type']??'');
    $ver  = sanitize($_POST['version']??'');
    $desc = sanitize($_POST['description']??'');
    $auth = sanitize($_POST['author']??'');
    $tags = sanitize($_POST['tags']??'');
    $img  = conv_drive(trim($_POST['image']??''));
    $dl   = conv_drive(trim($_POST['download']??''));
    $feat = isset($_POST['featured'])?1:0;
    if (!$name||!$type||!$dl) { $err='يرجى ملء الاسم والنوع ورابط التنزيل'; }
    else {
        if ($id) {
            foreach($mods as &$m) { if($m['id']===$id){$m=array_merge($m,compact('name','type','ver','desc','auth','tags','img','dl','feat')+['version'=>$ver,'description'=>$desc,'author'=>$auth,'image'=>$img,'download'=>$dl,'featured'=>$feat,'updated_at'=>date('Y-m-d H:i:s')]); break;} } unset($m);
        } else {
            $mods[]=['id'=>generate_id($mods),'name'=>$name,'type'=>$type,'version'=>$ver,'description'=>$desc,'author'=>$auth,'tags'=>$tags,'image'=>$img,'download'=>$dl,'featured'=>$feat,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')];
        }
        write_encrypted_json('mods.json',$mods);
        header('Location: manage_mods.php?ok='.($id?'edited':'added')); exit;
    }
}
$edit=null;
if($action==='edit'&&isset($_GET['id'])){ foreach($mods as $m){ if($m['id']===(int)$_GET['id']){$edit=$m;break;} } }
$ok_map=['added'=>'تمت الإضافة','edited'=>'تم التعديل','deleted'=>'تم الحذف'];
$ok=$_GET['ok']??''; if($ok&&isset($ok_map[$ok])) $msg=$ok_map[$ok];
?><!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>إدارة الموديات | Iraqminer</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<?php include '_sidebar.php'; ?>
<main class="main">
  <div class="topbar">
    <h1><?= $action==='list'?'إدارة <span>الموديات</span>':($action==='edit'?'تعديل <span>المود</span>':'إضافة <span>مود جديد</span>') ?></h1>
    <?php if($action==='list'): ?><a href="?action=add" class="btn btn-p"><i class="fas fa-plus"></i> إضافة مود</a><?php else: ?><a href="manage_mods.php" class="btn btn-i"><i class="fas fa-list"></i> الكل</a><?php endif; ?>
  </div>
  <?php if($msg): ?><div class="al al-ok"><i class="fas fa-check-circle"></i> <?= e($msg) ?></div><?php endif; ?>
  <?php if($err): ?><div class="al al-err"><i class="fas fa-times-circle"></i> <?= e($err) ?></div><?php endif; ?>

  <?php if($action==='list'): ?>
  <div class="card"><div class="ct"><i class="fas fa-list"></i> الموديات (<?= count($mods) ?>)</div>
  <?php if(empty($mods)): ?><div class="empty"><i class="fas fa-puzzle-piece"></i><p>لا توجد موديات. <a href="?action=add">أضف أول مود!</a></p></div>
  <?php else: ?><div class="tw"><table>
    <tr><th>الصورة</th><th>الاسم</th><th>النوع</th><th>الإصدار</th><th>المؤلف</th><th>مميز</th><th>الإجراءات</th></tr>
    <?php foreach(array_reverse($mods) as $m): ?><tr>
      <td><?php if(!empty($m['image'])): ?><img src="<?= e($m['image']) ?>" class="mthumb" alt=""><?php else: ?><div class="mthumb df ac" style="justify-content:center;background:rgba(0,230,118,.08)"><i class="fas fa-puzzle-piece" style="color:var(--accent)"></i></div><?php endif; ?></td>
      <td><strong><?= e($m['name']??'') ?></strong></td><td><span class="bg bg-g"><?= e($m['type']??'') ?></span></td>
      <td><?= e($m['version']??'') ?></td><td><?= e($m['author']??'') ?></td>
      <td><?= ($m['featured']??0)?'<span class="bg bg-o">نعم</span>':'' ?></td>
      <td class="df g2"><a href="?action=edit&id=<?= $m['id'] ?>" class="btn btn-i btn-sm"><i class="fas fa-edit"></i></a><a href="?action=delete&id=<?= $m['id'] ?>" class="btn btn-d btn-sm" onclick="return confirm('حذف هذا المود؟')"><i class="fas fa-trash"></i></a></td>
    </tr><?php endforeach; ?>
  </table></div><?php endif; ?>
  </div>

  <?php else: ?>
  <div class="card"><form method="POST">
    <?php if($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
    <div class="fg-grid">
      <div class="fg"><label>اسم المود *</label><input type="text" name="name" value="<?= e($edit['name']??'') ?>" placeholder="OptiFine" required></div>
      <div class="fg"><label>النوع *</label><select name="type" required>
        <option value="">اختر النوع</option>
        <?php foreach(['مود','حزمة نصيرة','خريطة','أداة'] as $t): ?>
        <option value="<?= e($t) ?>" <?= ($edit['type']??'')===$t?'selected':'' ?>><?= e($t) ?></option>
        <?php endforeach; ?>
      </select></div>
      <div class="fg"><label>الإصدار</label><input type="text" name="version" value="<?= e($edit['version']??'') ?>" placeholder="1.21.0"></div>
      <div class="fg"><label>المؤلف</label><input type="text" name="author" value="<?= e($edit['author']??'') ?>" placeholder="اسم المطور"></div>
      <div class="fg"><label>رابط الصورة (Google Drive)</label><input type="text" name="image" value="<?= e($edit['image']??'') ?>" placeholder="رابط Google Drive"><small style="color:var(--muted);font-size:.73rem">يُحوَّل تلقائياً لرابط مباشر</small></div>
      <div class="fg"><label>رابط التنزيل * (Google Drive)</label><input type="text" name="download" value="<?= e($edit['download']??'') ?>" placeholder="رابط Google Drive" required></div>
      <div class="fg"><label>الوسوم (مفصولة بفاصلة)</label><input type="text" name="tags" value="<?= e($edit['tags']??'') ?>" placeholder="أداء، سلاح، رسومات"></div>
    </div>
    <div class="fg"><label>الوصف</label><textarea name="description" placeholder="وصف المود..."><?= e($edit['description']??'') ?></textarea></div>
    <div class="fcheck"><input type="checkbox" name="featured" id="feat" value="1" <?= ($edit['featured']??0)?'checked':'' ?>><label for="feat">مود مميز (يظهر في السلايدر الرئيسي)</label></div>
    <div class="df g3 mt3"><button type="submit" class="btn btn-p"><i class="fas fa-save"></i> حفظ</button><a href="manage_mods.php" class="btn btn-i"><i class="fas fa-times"></i> إلغاء</a></div>
  </form></div>
  <?php endif; ?>
</main></div></body></html>

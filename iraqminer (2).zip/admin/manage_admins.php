<?php
require_once __DIR__ . '/config.php';
require_admin();
if (!is_main_admin()) { header('Location: dashboard.php'); exit; }
$admins = read_encrypted_json('admins.json');
$action = $_GET['action'] ?? 'list';
$msg = $err = '';
$all_perms = ['manage_mods'=>'إدارة الموديات','manage_requests'=>'إدارة الطلبات','update_minecraft'=>'تحديث ماينكرافت','view_stats'=>'عرض الإحصائيات'];

if ($action==='delete' && isset($_GET['id'])) {
    $did=(int)$_GET['id']; $tgt=null;
    foreach($admins as $a){ if($a['id']==$did){$tgt=$a;break;} }
    if($tgt && $tgt['role']!=='main'){ $admins=array_values(array_filter($admins,fn($a)=>$a['id']!=$did)); write_encrypted_json('admins.json',$admins); header('Location: manage_admins.php?ok=deleted'); exit; }
    header('Location: manage_admins.php?em=main'); exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id=$_POST['id']??(int)0; $id=(int)$id;
    $username=sanitize($_POST['username']??''); $password=$_POST['password']??'';
    $perms=array_map('sanitize',(array)($_POST['permissions']??[]));
    if(!$username){$err='اسم المستخدم مطلوب';}
    elseif(!$id&&!$password){$err='كلمة المرور مطلوبة';}
    else{
        foreach($admins as $a){ if($a['username']===$username&&$a['id']!=$id){$err='اسم المستخدم مستخدم';break;} }
        if(!$err){
            if($id){ foreach($admins as &$a){ if($a['id']==$id&&$a['role']!=='main'){ $a['username']=$username; $a['permissions']=$perms; if($password)$a['password']=password_hash($password,PASSWORD_BCRYPT,['cost'=>12]); $a['updated_at']=date('Y-m-d H:i:s'); break; } } unset($a); }
            else{ $admins[]=['id'=>generate_id($admins),'username'=>$username,'password'=>password_hash($password,PASSWORD_BCRYPT,['cost'=>12]),'role'=>'sub','permissions'=>$perms?:['manage_mods','manage_requests'],'created_at'=>date('Y-m-d H:i:s')]; }
            write_encrypted_json('admins.json',$admins); header('Location: manage_admins.php?ok='.($id?'edited':'added')); exit;
        }
    }
}
$edit=null;
if($action==='edit'&&isset($_GET['id'])){ foreach($admins as $a){if($a['id']==(int)$_GET['id']){$edit=$a;break;}} }
$ok_map=['added'=>'تمت الإضافة','edited'=>'تم التعديل','deleted'=>'تم الحذف'];
$em_map=['main'=>'لا يمكن حذف المشرف الرئيسي'];
$ok=$_GET['ok']??''; $em=$_GET['em']??'';
if($ok&&isset($ok_map[$ok])) $msg=$ok_map[$ok];
if($em&&isset($em_map[$em])) $err=$em_map[$em];
?><!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>إدارة المشرفين | Iraqminer</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<?php include '_sidebar.php'; ?>
<main class="main">
  <div class="topbar"><h1>إدارة <span>المشرفين</span></h1><?php if($action==='list'): ?><a href="?action=add" class="btn btn-p"><i class="fas fa-plus"></i> مشرف جديد</a><?php else: ?><a href="manage_admins.php" class="btn btn-i"><i class="fas fa-list"></i> الكل</a><?php endif; ?></div>
  <?php if($msg): ?><div class="al al-ok"><i class="fas fa-check-circle"></i> <?= e($msg) ?></div><?php endif; ?>
  <?php if($err): ?><div class="al al-err"><i class="fas fa-times-circle"></i> <?= e($err) ?></div><?php endif; ?>

  <?php if($action==='list'): ?>
  <div class="card"><div class="ct"><i class="fas fa-users-cog"></i> المشرفون</div>
  <div class="tw"><table>
    <tr><th>ID</th><th>المستخدم</th><th>الدور</th><th>الصلاحيات</th><th>الإنشاء</th><th>إجراءات</th></tr>
    <?php foreach($admins as $a): ?><tr>
      <td><?= $a['id'] ?></td><td><strong><?= e($a['username']) ?></strong></td>
      <td><?= $a['role']==='main'?'<span class="bg bg-o">رئيسي</span>':'<span class="bg bg-b">فرعي</span>' ?></td>
      <td><?php if($a['role']==='main'): ?><span class="bg bg-g">كاملة</span><?php else: foreach((array)($a['permissions']??[]) as $p): ?><span class="bg bg-b" style="margin:2px"><?= e($all_perms[$p]??$p) ?></span><?php endforeach; endif; ?></td>
      <td><?= e(substr($a['created_at']??'',0,10)) ?></td>
      <td class="df g2"><?php if($a['role']!=='main'): ?>
        <a href="?action=edit&id=<?= $a['id'] ?>" class="btn btn-i btn-sm"><i class="fas fa-edit"></i></a>
        <a href="?action=delete&id=<?= $a['id'] ?>" class="btn btn-d btn-sm" onclick="return confirm('حذف؟')"><i class="fas fa-trash"></i></a>
      <?php else: ?><span style="color:var(--muted);font-size:.78rem">–</span><?php endif; ?></td>
    </tr><?php endforeach; ?>
  </table></div></div>

  <?php else: ?>
  <div class="card"><div class="ct"><i class="fas fa-user-plus"></i> <?= $edit?'تعديل المشرف':'إضافة مشرف فرعي' ?></div>
  <form method="POST">
    <?php if($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
    <div class="fg-grid">
      <div class="fg"><label>اسم المستخدم *</label><input type="text" name="username" value="<?= e($edit['username']??'') ?>" required></div>
      <div class="fg"><label>كلمة المرور <?= $edit?'(فارغ = بدون تغيير)':'*' ?></label><input type="password" name="password" <?= $edit?'':'required' ?>></div>
    </div>
    <div class="fg"><label>الصلاحيات</label>
      <?php $cur=(array)($edit['permissions']??['manage_mods','manage_requests']); foreach($all_perms as $k=>$l): ?>
      <div class="fcheck"><input type="checkbox" name="permissions[]" id="p_<?= $k ?>" value="<?= $k ?>" <?= in_array($k,$cur)?'checked':'' ?>><label for="p_<?= $k ?>"><?= $l ?></label></div>
      <?php endforeach; ?>
    </div>
    <div class="df g3 mt3"><button type="submit" class="btn btn-p"><i class="fas fa-save"></i> حفظ</button><a href="manage_admins.php" class="btn btn-i"><i class="fas fa-times"></i> إلغاء</a></div>
  </form></div>
  <?php endif; ?>
</main></div></body></html>

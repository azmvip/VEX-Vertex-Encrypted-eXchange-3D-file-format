<?php
define('DATA_DIR', __DIR__ . '/data/');
define('ENCRYPTION_KEY', 'IraqMiner@2025!SecureKey#XkZ9pLmQ7rTvWbNj4sDcF1eHuYoAi6g');
define('ENCRYPTION_CIPHER', 'AES-256-CBC');

function enc(string $d):string{$iv=random_bytes(openssl_cipher_iv_length(ENCRYPTION_CIPHER));return base64_encode($iv.'::'.openssl_encrypt($d,ENCRYPTION_CIPHER,ENCRYPTION_KEY,0,$iv));}
function dec(string $d):string{$r=base64_decode($d);if(strpos($r,'::')===false)return $d;[$iv,$e]=explode('::',$r,2);$x=openssl_decrypt($e,ENCRYPTION_CIPHER,ENCRYPTION_KEY,0,$iv);return $x===false?'':$x;}
function rj(string $f):array{$p=DATA_DIR.$f;if(!file_exists($p))return[];$raw=file_get_contents($p);if(!$raw)return[];$d=json_decode(dec(trim($raw)),true);return is_array($d)?$d:[];}
function wj(string $f,array $d):bool{if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0755,true);return file_put_contents(DATA_DIR.$f,enc(json_encode($d,JSON_UNESCAPED_UNICODE)),LOCK_EX)!==false;}
function e(string $s):string{return htmlspecialchars($s,ENT_QUOTES,'UTF-8');}

// Bootstrap data
if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0755,true);
foreach(['tokens.json'=>[],'mods.json'=>[],'requests.json'=>[],'stats.json'=>['visitors'=>['total_pageviews'=>0,'unique_visitors'=>0,'daily'=>[]],'downloads'=>['total'=>0,'per_mod'=>[]]],'minecraft.json'=>['version'=>'1.21.0','description'=>'أحدث إصدار من ماينكرافت بيدروك','image'=>'','platforms'=>['Android','iOS','Windows'],'download_url'=>'https://www.minecraft.net/ar-sa/download'],'settings.json'=>['site_name'=>'Iraqminer','per_page'=>12]] as $file=>$def){if(!file_exists(DATA_DIR.$file))wj($file,$def);}
$admins=rj('admins.json');
if(empty($admins)){wj('admins.json',[['id'=>1,'username'=>'iraqmineradmin','password'=>password_hash('Js7@pQk!9tXz#2Lm',PASSWORD_BCRYPT,['cost'=>12]),'role'=>'main','permissions'=>['all'],'created_at'=>date('Y-m-d H:i:s')]]);}

$mods   = rj('mods.json');
$mc     = rj('minecraft.json');
$stats  = rj('stats.json');
$featured = array_values(array_filter($mods,fn($m)=>!empty($m['featured'])));
$dl_cnt = $stats['downloads']['per_mod']??[];
$cat_cnt = [];
foreach($mods as $m){$t=$m['type']??'';$cat_cnt[$t]=($cat_cnt[$t]??0)+1;}
$total_dl  = $stats['downloads']['total']??0;
$total_vis = $stats['visitors']['unique_visitors']??0;
$cat_icons = ['مود'=>'fa-puzzle-piece','حزمة نصيرة'=>'fa-palette','خريطة'=>'fa-map','أداة'=>'fa-wrench'];
$cat_cols  = ['مود'=>'#00e676','حزمة نصيرة'=>'#29b6f6','خريطة'=>'#ffa726','أداة'=>'#ce93d8'];
?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="Iraqminer – أكبر منصة عربية لتعديلات ماينكرافت بيدروك. حمّل أحدث الموديات وحزم النسيج والخرائط مجاناً.">
<meta name="keywords" content="ماينكرافت,موديات,بيدروك,Minecraft Bedrock,مود,خريطة,عراق,عربي">
<meta name="author" content="Iraqminer">
<meta property="og:title" content="Iraqminer | منصة تعديلات ماينكرافت بيدروك">
<meta property="og:type" content="website">
<meta name="theme-color" content="#00e676">
<title>Iraqminer | منصة تعديلات ماينكرافت بيدروك</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;900&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- Navbar -->
<nav class="nav" id="nav">
  <div class="nw">
    <a href="#" class="nl"><div class="li">IM</div><span>Iraqminer</span></a>
    <div class="nlinks">
      <a href="#hero" class="on">الرئيسية</a>
      <a href="#mods">الموديات</a>
      <a href="#mc">ماينكرافت</a>
      <a href="#about">عنّا</a>
    </div>
    <div class="na">
      <button class="tt" id="themeToggle" aria-label="السمة"><i class="fas fa-sun"></i></button>
      <a href="#" class="brq orq"><i class="fas fa-plus"></i> طلب مود</a>
      <a href="admin/index.php" class="badm" title="التحكم"><i class="fas fa-cog"></i></a>
      <button class="hbg" id="hbg" aria-label="القائمة" aria-expanded="false"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>

<!-- Mobile Menu -->
<div class="mmenu" id="mmenu" role="dialog" aria-modal="true">
  <button class="mmc" id="mmc" aria-label="إغلاق"><i class="fas fa-times"></i></button>
  <a href="#hero">الرئيسية</a>
  <a href="#mods">الموديات</a>
  <a href="#mc">ماينكرافت</a>
  <a href="#about">عنّا</a>
  <a href="#" class="orq" style="color:var(--ac)"><i class="fas fa-plus"></i> طلب مود</a>
  <a href="admin/index.php"><i class="fas fa-cog"></i> التحكم</a>
</div>

<!-- Hero -->
<section id="hero" class="hero">
  <div class="hbg2"></div>
  <div class="hpar"></div>
  <div style="position:relative;z-index:1;width:100%;max-width:780px;margin:0 auto">
    <div class="hico">IM</div>
    <div class="hbadge">المنصة العربية الأولى</div>
    <h1>عالم من <span class="gt">الموديات</span><br>لماينكرافت بيدروك</h1>
    <p>اكتشف أضخم مكتبة عربية من الموديات وحزم النسيج والخرائط لـ Minecraft Bedrock Edition – مجاناً.</p>
    <div class="hact">
      <a href="#mods" class="btn-g"><i class="fas fa-download"></i> تصفّح الموديات</a>
      <a href="#" class="btn-o orq"><i class="fas fa-paper-plane"></i> شارك مودك</a>
    </div>
    <div class="hsts">
      <div class="hs"><div class="num"><?= count($mods) ?>+</div><div class="lbl">مود متاح</div></div>
      <div class="hs"><div class="num"><?= number_format($total_dl) ?>+</div><div class="lbl">تنزيل</div></div>
      <div class="hs"><div class="num"><?= number_format($total_vis) ?>+</div><div class="lbl">زائر</div></div>
    </div>
  </div>
</section>

<!-- Search -->
<div class="ss c">
  <div class="sb" role="search">
    <input type="text" id="si" placeholder="ابحث عن مود، خريطة، أداة..." aria-label="بحث">
    <button onclick="filterMods()"><i class="fas fa-search"></i></button>
  </div>
  <div class="stags">
    <?php foreach(['مود','حزمة نصيرة','خريطة','أداة'] as $t): ?>
    <span class="stag"><?= e($t) ?></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- Categories -->
<section class="cats">
  <div class="c">
    <div class="sh"><div class="sl">الأقسام</div><h2 class="st">تصفّح حسب النوع</h2></div>
    <div class="cg">
      <a href="#mods" class="cc" data-filter="all"><div class="cci"><i class="fas fa-th-large" style="color:#00e676"></i></div><div class="ccn">الكل</div><div class="ccc"><?= count($mods) ?> مود</div></a>
      <?php foreach($cat_icons as $cat=>$icon): $col=$cat_cols[$cat]??'#00e676'; $cnt=$cat_cnt[$cat]??0; ?>
      <a href="#mods" class="cc" data-filter="<?= e($cat) ?>"><div class="cci" style="background:<?= $col ?>1a"><i class="fas <?= $icon ?>" style="color:<?= $col ?>"></i></div><div class="ccn"><?= e($cat) ?></div><div class="ccc"><?= $cnt ?> مود</div></a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Featured Slider -->
<?php if(!empty($featured)): ?>
<section class="feat">
  <div class="c">
    <div class="sh"><div class="sl">مميّز</div><h2 class="st">أبرز الموديات</h2></div>
    <div class="slw">
      <div class="slt" id="slt">
        <?php foreach($featured as $fm): ?>
        <div class="sl2" onclick='openMod(<?= json_encode(['id'=>(string)$fm['id'],'name'=>$fm['name']??'','type'=>$fm['type']??'','author'=>$fm['author']??'','version'=>$fm['version']??'','description'=>$fm['description']??'','image'=>$fm['image']??'','download'=>$fm['download']??''],JSON_UNESCAPED_UNICODE) ?>)' style="cursor:pointer">
          <?php if(!empty($fm['image'])): ?><img src="<?= e($fm['image']) ?>" class="sli" alt="<?= e($fm['name']) ?>" loading="lazy">
          <?php else: ?><div class="slp"><i class="fas fa-puzzle-piece"></i></div><?php endif; ?>
          <div class="slov">
            <div class="sltype"><?= e($fm['type']??'') ?></div>
            <div class="slname"><?= e($fm['name']) ?></div>
            <div class="sldesc"><?= e($fm['description']??'') ?></div>
            <a href="<?= e($fm['download']??'#') ?>" target="_blank" rel="noopener" class="btn-g" style="font-size:.83rem;padding:9px 18px" onclick="event.stopPropagation();trackDl('<?= e($fm['id']) ?>','<?= e($fm['download']??'') ?>')"><i class="fas fa-download"></i> تنزيل</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="slctl">
      <button class="slbtn" id="slPrev"><i class="fas fa-chevron-right"></i></button>
      <div class="sldots"><?php for($i=0;$i<count($featured);$i++): ?><div class="sldot <?= $i===0?'on':'' ?>"></div><?php endfor; ?></div>
      <button class="slbtn" id="slNext"><i class="fas fa-chevron-left"></i></button>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- Mods Grid -->
<section id="modsS" class="mods">
  <div class="c">
    <div class="sh"><div class="sl">المكتبة</div><h2 class="st">جميع الموديات</h2><p class="sd">تشكيلة واسعة لتحسين تجربتك</p></div>
    <div class="fb">
      <button class="fb-btn on" data-filter="all">الكل (<?= count($mods) ?>)</button>
      <?php foreach($cat_icons as $cat=>$icon): $cnt=$cat_cnt[$cat]??0; if($cnt===0)continue; ?>
      <button class="fb-btn" data-filter="<?= e($cat) ?>"><i class="fas <?= $icon ?>"></i> <?= e($cat) ?> (<?= $cnt ?>)</button>
      <?php endforeach; ?>
    </div>
    <div class="mg" id="mg">
      <?php if(empty($mods)): ?>
      <div class="nomod"><i class="fas fa-puzzle-piece"></i><h3>لا توجد موديات بعد</h3><p>تابعنا قريباً!</p><a href="#" class="btn-g orq" style="margin-top:14px"><i class="fas fa-plus"></i> أضف مودك</a></div>
      <?php else: foreach(array_reverse($mods) as $mod): $dlc=$dl_cnt[$mod['id']]??0; ?>
      <article class="mc <?= ($mod['featured']??0)?'ft':'' ?> si2"
        data-name="<?= e(strtolower($mod['name']??'')) ?>"
        data-type="<?= e(strtolower($mod['type']??'')) ?>"
        data-desc="<?= e(strtolower($mod['description']??'')) ?>"
        data-tags="<?= e(strtolower($mod['tags']??'')) ?>"
        role="button" tabindex="0" aria-label="<?= e($mod['name']??'') ?>"
        onclick='openMod(<?= json_encode(['id'=>(string)$mod['id'],'name'=>$mod['name']??'','type'=>$mod['type']??'','author'=>$mod['author']??'','version'=>$mod['version']??'','description'=>$mod['description']??'','image'=>$mod['image']??'','download'=>$mod['download']??''],JSON_UNESCAPED_UNICODE) ?>)'>
        <?php if(!empty($mod['image'])): ?><img src="<?= e($mod['image']) ?>" class="mth" alt="<?= e($mod['name']??'') ?>" loading="lazy">
        <?php else: ?><div class="mthp"><i class="fas fa-puzzle-piece"></i></div><?php endif; ?>
        <div class="mb">
          <div class="mtype"><?= e($mod['type']??'مود') ?></div>
          <div class="mname"><?= e($mod['name']??'') ?></div>
          <?php if(!empty($mod['description'])): ?><div class="mdesc"><?= e($mod['description']) ?></div><?php endif; ?>
          <div class="mft">
            <div class="mmeta">
              <?php if(!empty($mod['version'])): ?><span><i class="fas fa-tag"></i><?= e($mod['version']) ?></span><?php endif; ?>
              <span><i class="fas fa-download"></i><span class="dlc" data-id="<?= e($mod['id']) ?>"><?= number_format($dlc) ?></span></span>
            </div>
            <button class="bdl" onclick="event.stopPropagation();trackDl('<?= e($mod['id']) ?>','<?= e($mod['download']??'') ?>')" aria-label="تنزيل"><i class="fas fa-download"></i> تنزيل</button>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
      <div class="nomod" id="noMods" style="display:none"><i class="fas fa-search"></i><h3>لا نتائج</h3><p>جرّب مصطلح آخر</p></div>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- Minecraft -->
<section id="mc" class="mcs">
  <div class="c">
    <div class="sh"><div class="sl">ماينكرافت</div><h2 class="st">تنزيل ماينكرافت بيدروك</h2></div>
    <div class="mcc">
      <?php if(!empty($mc['image'])): ?><img src="<?= e($mc['image']) ?>" class="mcimg" alt="Minecraft" loading="lazy">
      <?php else: ?><div class="mcimgp">⬡</div><?php endif; ?>
      <div class="mcco">
        <div class="mcvb"><i class="fas fa-cube"></i> الإصدار <?= e($mc['version']??'1.21.0') ?></div>
        <h3 class="mct">Minecraft Bedrock Edition</h3>
        <p class="mcd"><?= e($mc['description']??'') ?></p>
        <?php if(!empty($mc['platforms'])): ?>
        <div class="mcps"><?php foreach((array)$mc['platforms'] as $p): ?><span class="mcp"><i class="fas fa-check"></i> <?= e($p) ?></span><?php endforeach; ?></div>
        <?php endif; ?>
        <a href="<?= e($mc['download_url']??'#') ?>" target="_blank" rel="noopener" class="btn-g"><i class="fas fa-download"></i> تنزيل مجاناً</a>
      </div>
    </div>
  </div>
</section>

<!-- About -->
<section id="about" class="about">
  <div class="c">
    <div class="sh"><div class="sl">عنّا</div><h2 class="st">لماذا Iraqminer؟</h2><p class="sd">منصة عربية متكاملة لماينكرافت بيدروك</p></div>
    <div class="ag">
      <div class="ac2"><div class="aci"><i class="fas fa-shield-alt"></i></div><h3>آمن وموثوق</h3><p>كل مود يمر بمراجعة دقيقة قبل النشر.</p></div>
      <div class="ac2"><div class="aci"><i class="fas fa-bolt"></i></div><h3>تنزيل سريع</h3><p>روابط مباشرة عبر Google Drive بأعلى سرعة.</p></div>
      <div class="ac2"><div class="aci"><i class="fas fa-language"></i></div><h3>واجهة عربية</h3><p>مصمّمة خصيصاً للمستخدمين العرب.</p></div>
      <div class="ac2"><div class="aci"><i class="fas fa-sync-alt"></i></div><h3>تحديث مستمر</h3><p>نواكب أحدث إصدارات ماينكرافت بيدروك.</p></div>
      <div class="ac2"><div class="aci"><i class="fas fa-users"></i></div><h3>مجتمع نشط</h3><p>انضم إلى آلاف اللاعبين وشارك موداتك.</p></div>
      <div class="ac2"><div class="aci"><i class="fas fa-mobile-alt"></i></div><h3>يعمل على الجوال</h3><p>تصميم متجاوب يعمل على كل الأجهزة.</p></div>
    </div>
  </div>
</section>

<!-- Mod Detail Modal -->
<div class="mov" id="modMov" role="dialog" aria-modal="true">
  <div class="mbox">
    <div class="mhd"><h2 id="mName"></h2><button class="mxbtn" id="modMClose"><i class="fas fa-times"></i></button></div>
    <div class="mbd">
      <img id="mImg" class="mimg" src="" alt="" loading="lazy">
      <div class="mmta">
        <span><i class="fas fa-tag"></i><span id="mType"></span></span>
        <span><i class="fas fa-user"></i><span id="mAuthor"></span></span>
        <span><i class="fas fa-code-branch"></i><span id="mVer"></span></span>
        <span><i class="fas fa-download"></i><span id="mDlCnt">0</span> تنزيل</span>
      </div>
      <p class="mdsc" id="mDesc"></p>
      <div class="mact">
        <a href="#" class="btn-g" id="mDlBtn" target="_blank" rel="noopener"><i class="fas fa-download"></i> تنزيل الآن</a>
        <button class="btn-o" onclick="closeMod()"><i class="fas fa-times"></i> إغلاق</button>
      </div>
    </div>
  </div>
</div>

<!-- Request Modal -->
<div class="mov" id="reqMov" role="dialog" aria-modal="true">
  <div class="mbox">
    <div class="mhd"><h2><i class="fas fa-paper-plane" style="color:var(--ac)"></i> طلب رفع مود</h2><button class="mxbtn" id="reqMClose"><i class="fas fa-times"></i></button></div>
    <div class="mbd">
      <div class="fnote"><i class="fas fa-info-circle"></i><span>سيراجع فريقنا طلبك وستصلك رسالة على بريدك عند القبول.</span></div>
      <form class="rform" id="reqForm" novalidate style="margin-top:16px">
        <div class="rfg">
          <div class="ff"><label>اسم المود *</label><input type="text" name="mod_name" placeholder="OptiFine" required></div>
          <div class="ff"><label>النوع *</label><select name="mod_type" required><option value="">اختر</option><option>مود</option><option>حزمة نصيرة</option><option>خريطة</option><option>أداة</option></select></div>
        </div>
        <div class="ff"><label>الوصف</label><textarea name="description" placeholder="وصف مفصّل..." rows="3"></textarea></div>
        <div class="ff"><label>رابط ملف المود (Google Drive) *</label><input type="url" name="file_url" placeholder="https://drive.google.com/file/d/..." required></div>
        <div class="ff"><label>رابط صورة المود (Google Drive)</label><input type="url" name="image_url" placeholder="https://drive.google.com/file/d/..."></div>
        <div class="rfg">
          <div class="ff"><label>اسمك *</label><input type="text" name="submitter_name" required></div>
          <div class="ff"><label>عمرك</label><input type="number" name="submitter_age" min="6" max="99"></div>
          <div class="ff"><label>بريدك الإلكتروني *</label><input type="email" name="submitter_email" placeholder="example@gmail.com" required></div>
        </div>
        <div class="mact">
          <button type="submit" class="btn-g" style="min-width:150px"><i class="fas fa-paper-plane"></i> إرسال</button>
          <button type="button" class="btn-o" onclick="closeReq()"><i class="fas fa-times"></i> إلغاء</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Footer -->
<footer>
  <div class="fg2">
    <div class="fb2">
      <div class="logo"><div class="li">IM</div><div class="ln">Iraqminer</div></div>
      <p>المنصة العربية الأولى لتعديلات ماينكرافت بيدروك.</p>
      <div style="display:flex;gap:9px">
        <?php foreach(['fab fa-discord'=>'Discord','fab fa-youtube'=>'YouTube','fab fa-telegram'=>'Telegram'] as $ic=>$t): ?>
        <a href="#" style="width:34px;height:34px;background:var(--ad);border:1px solid var(--b);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--ac)" title="<?= $t ?>"><i class="<?= $ic ?>"></i></a>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="fc"><h4>روابط سريعة</h4><ul><li><a href="#hero">الرئيسية</a></li><li><a href="#modsS">الموديات</a></li><li><a href="#mc">ماينكرافت</a></li><li><a href="#about">عنّا</a></li></ul></div>
    <div class="fc"><h4>أقسام</h4><ul><li><a href="#modsS">الموديات</a></li><li><a href="#modsS">حزم النسيج</a></li><li><a href="#modsS">الخرائط</a></li><li><a href="#modsS">الأدوات</a></li></ul></div>
    <div class="fc"><h4>للمطورين</h4><ul><li><a href="#" class="orq">طلب رفع مود</a></li><li><a href="admin/index.php">لوحة التحكم</a></li></ul></div>
  </div>
  <div class="fbot"><span>© <?= date('Y') ?> <a href="#">Iraqminer</a> – جميع الحقوق محفوظة</span><span>صُنع بـ <i class="fas fa-heart" style="color:#ef5350"></i> للمجتمع العربي</span></div>
</footer>

<button class="btt" id="btt"><i class="fas fa-chevron-up"></i></button>
<script src="assets/js/main.js"></script>
</body>
</html>

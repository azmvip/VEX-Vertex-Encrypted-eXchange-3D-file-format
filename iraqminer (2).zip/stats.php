<?php
define('DATA_DIR', __DIR__ . '/data/');
define('ENCRYPTION_KEY', 'IraqMiner@2025!SecureKey#XkZ9pLmQ7rTvWbNj4sDcF1eHuYoAi6g');
define('ENCRYPTION_CIPHER', 'AES-256-CBC');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function enc(string $d):string{$iv=random_bytes(openssl_cipher_iv_length(ENCRYPTION_CIPHER));return base64_encode($iv.'::'.openssl_encrypt($d,ENCRYPTION_CIPHER,ENCRYPTION_KEY,0,$iv));}
function dec(string $d):string{$r=base64_decode($d);if(strpos($r,'::')===false)return $d;[$iv,$e]=explode('::',$r,2);$x=openssl_decrypt($e,ENCRYPTION_CIPHER,ENCRYPTION_KEY,0,$iv);return $x===false?'':$x;}
function rj(string $f):array{$p=DATA_DIR.$f;if(!file_exists($p))return[];$r=file_get_contents($p);if(!$r)return[];$d=json_decode(dec(trim($r)),true);return is_array($d)?$d:[];}
function wj(string $f,array $d):bool{if(!is_dir(DATA_DIR))mkdir(DATA_DIR,0755,true);return file_put_contents(DATA_DIR.$f,enc(json_encode($d,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)),LOCK_EX)!==false;}
function sid(string $v):string{return preg_replace('/[^a-zA-Z0-9_\-]/','',substr($v,0,64));}

$type = $_POST['type'] ?? $_GET['type'] ?? '';

if ($type==='pageview') {
    $s=rj('stats.json');
    if(!isset($s['visitors'])) $s['visitors']=['total_pageviews'=>0,'unique_visitors'=>0,'daily'=>[]];
    $today=date('Y-m-d');
    if(!isset($s['visitors']['daily'][$today])) $s['visitors']['daily'][$today]=['pageviews'=>0,'uniques'=>0];
    $s['visitors']['total_pageviews']++;
    $s['visitors']['daily'][$today]['pageviews']++;
    $ip=$_SERVER['HTTP_X_FORWARDED_FOR']??$_SERVER['REMOTE_ADDR']??'';
    $vh=hash('sha256',$ip.($_SERVER['HTTP_USER_AGENT']??''));
    $tmp=sys_get_temp_dir().'/iqv_'.$vh;
    if(!file_exists($tmp)||(time()-filemtime($tmp))>1800){ touch($tmp); $s['visitors']['unique_visitors']++; $s['visitors']['daily'][$today]['uniques']++; }
    krsort($s['visitors']['daily']); $s['visitors']['daily']=array_slice($s['visitors']['daily'],0,90,true);
    wj('stats.json',$s); echo json_encode(['ok'=>true]); exit;
}
if ($type==='download') {
    $mid=sid($_POST['mod_id']??$_GET['mod_id']??'');
    if(!$mid){echo json_encode(['ok'=>false]);exit;}
    $s=rj('stats.json');
    if(!isset($s['downloads'])) $s['downloads']=['total'=>0,'per_mod'=>[]];
    $s['downloads']['total']++;
    $s['downloads']['per_mod'][$mid]=($s['downloads']['per_mod'][$mid]??0)+1;
    wj('stats.json',$s); echo json_encode(['ok'=>true,'count'=>$s['downloads']['per_mod'][$mid]]); exit;
}
if ($type==='get_count') {
    $mid=sid($_GET['mod_id']??'');
    $s=rj('stats.json');
    echo json_encode(['ok'=>true,'count'=>$s['downloads']['per_mod'][$mid]??0]); exit;
}
echo json_encode(['ok'=>false,'msg'=>'unknown type']);

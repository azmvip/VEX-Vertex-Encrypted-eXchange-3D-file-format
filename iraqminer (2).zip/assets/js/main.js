'use strict';

// Theme
const themeToggle = document.getElementById('themeToggle');
const saved = localStorage.getItem('iqm_theme') || 'dark';
document.documentElement.setAttribute('data-theme', saved);
setTI(saved);
function setTI(t) { if (themeToggle) themeToggle.querySelector('i').className = t === 'dark' ? 'fas fa-sun' : 'fas fa-moon'; }
if (themeToggle) themeToggle.addEventListener('click', () => {
  const n = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', n);
  localStorage.setItem('iqm_theme', n);
  setTI(n);
});

// Navbar
const nav = document.getElementById('nav');
if (nav) window.addEventListener('scroll', () => nav.classList.toggle('sc', scrollY > 55), {passive:true});

// Back to top
const btt = document.getElementById('btt');
if (btt) {
  window.addEventListener('scroll', () => btt.classList.toggle('vis', scrollY > 380), {passive:true});
  btt.addEventListener('click', () => scrollTo({top:0,behavior:'smooth'}));
}

// Mobile menu
const hbg  = document.getElementById('hbg');
const mmenu = document.getElementById('mmenu');
const mmc   = document.getElementById('mmc');
if (hbg && mmenu) {
  hbg.addEventListener('click', () => { mmenu.classList.add('op'); hbg.setAttribute('aria-expanded','true'); });
  mmc && mmc.addEventListener('click', () => { mmenu.classList.remove('op'); hbg.setAttribute('aria-expanded','false'); });
  mmenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => mmenu.classList.remove('op')));
}

// Particles
const pc = document.querySelector('.hpar');
if (pc) for (let i = 0; i < 16; i++) {
  const p = document.createElement('div');
  p.className = 'par';
  p.style.cssText = `left:${Math.random()*100}%;top:${Math.random()*100}%;width:${Math.random()*3+2}px;height:${Math.random()*3+2}px;animation-delay:${Math.random()*6}s;animation-duration:${Math.random()*4+4}s`;
  pc.appendChild(p);
}

// Toast
function toast(msg, type = 'in', dur = 3500) {
  const icons = {ok:'fa-check-circle', er:'fa-times-circle', in:'fa-info-circle'};
  let con = document.querySelector('.tcon');
  if (!con) { con = document.createElement('div'); con.className = 'tcon'; document.body.appendChild(con); }
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<i class="fas ${icons[type]||icons.in} ti"></i><span class="tm2">${msg}</span>`;
  con.appendChild(t);
  requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('sh')));
  setTimeout(() => { t.classList.remove('sh'); setTimeout(() => t.remove(), 420); }, dur);
}

// Mod modal
const modMov   = document.getElementById('modMov');
const modMClose = document.getElementById('modMClose');

function openMod(mod) {
  if (!modMov) return;
  document.getElementById('mName').textContent    = mod.name    || '';
  document.getElementById('mType').textContent    = mod.type    || '';
  document.getElementById('mAuthor').textContent  = mod.author  || '';
  document.getElementById('mVer').textContent     = mod.version || '';
  document.getElementById('mDesc').textContent    = mod.description || '';
  const dlBtn = document.getElementById('mDlBtn');
  if (dlBtn) { dlBtn.href = mod.download || '#'; dlBtn.onclick = e => { e.preventDefault(); trackDl(mod.id, mod.download); }; }
  const img = document.getElementById('mImg');
  if (img) { img.style.display = mod.image ? 'block' : 'none'; if (mod.image) img.src = mod.image; }
  fetch(`stats.php?type=get_count&mod_id=${encodeURIComponent(mod.id)}`).then(r=>r.json()).then(d=>{const c=document.getElementById('mDlCnt');if(c)c.textContent=(d.count||0).toLocaleString('ar');}).catch(()=>{});
  modMov.classList.add('op'); document.body.style.overflow = 'hidden';
}
function closeMod() { if (modMov) { modMov.classList.remove('op'); document.body.style.overflow = ''; } }
if (modMClose) modMClose.addEventListener('click', closeMod);
if (modMov)    modMov.addEventListener('click', e => { if (e.target === modMov) closeMod(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMod(); closeReq(); } });

// Download tracker
function trackDl(id, url) {
  const fd = new FormData(); fd.append('type','download'); fd.append('mod_id', id);
  fetch('stats.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{
    if (d.ok) { const c=document.getElementById('mDlCnt'); if(c)c.textContent=(d.count||0).toLocaleString('ar'); document.querySelectorAll(`.dlc[data-id="${id}"]`).forEach(el=>el.textContent=(d.count||0).toLocaleString('ar')); }
  }).catch(()=>{});
  if (url && url !== '#') window.open(url,'_blank','noopener,noreferrer');
  toast('جارٍ التنزيل...','ok');
}

// Request modal
const reqMov   = document.getElementById('reqMov');
const reqMClose = document.getElementById('reqMClose');
const reqForm   = document.getElementById('reqForm');
function openReq()  { if (reqMov) { reqMov.classList.add('op');    document.body.style.overflow = 'hidden'; } }
function closeReq() { if (reqMov) { reqMov.classList.remove('op'); document.body.style.overflow = ''; } }
document.querySelectorAll('.orq').forEach(b => b.addEventListener('click', e => { e.preventDefault(); openReq(); }));
if (reqMClose) reqMClose.addEventListener('click', closeReq);
if (reqMov)    reqMov.addEventListener('click', e => { if (e.target === reqMov) closeReq(); });

if (reqForm) {
  reqForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = reqForm.querySelector('[type=submit]'); const orig = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span> إرسال...';
    try {
      const res = await fetch('request.php',{method:'POST',body:new FormData(reqForm)});
      const d   = await res.json();
      if (d.ok) { toast(d.msg,'ok',5000); reqForm.reset(); setTimeout(closeReq,1200); }
      else { toast(d.msg||'حدث خطأ','er'); }
    } catch { toast('خطأ في الاتصال','er'); }
    finally { btn.disabled=false; btn.innerHTML=orig; }
  });
}

// Slider
function initSlider() {
  const t   = document.getElementById('slt');
  const dots = document.querySelectorAll('.sldot');
  const prev = document.getElementById('slPrev');
  const next = document.getElementById('slNext');
  if (!t || t.children.length === 0) return;
  let cur = 0, tim;
  function go(i) { cur=(i+t.children.length)%t.children.length; t.style.transform=`translateX(${cur*100}%)`; dots.forEach((d,j)=>d.classList.toggle('on',j===cur)); }
  function fwd() { go(cur+1); }
  function start() { tim=setInterval(fwd,4500); }
  function stop()  { clearInterval(tim); }
  if (prev) prev.addEventListener('click',()=>{stop();go(cur-1);start();});
  if (next) next.addEventListener('click',()=>{stop();fwd();start();});
  dots.forEach((d,i)=>d.addEventListener('click',()=>{stop();go(i);start();}));
  let sx=0;
  t.addEventListener('touchstart',e=>{sx=e.touches[0].clientX;},{passive:true});
  t.addEventListener('touchend',e=>{const d=sx-e.changedTouches[0].clientX;if(Math.abs(d)>50){stop();d>0?fwd():go(cur-1);start();}},{passive:true});
  go(0); start();
}
initSlider();

// Filter/Search
const si    = document.getElementById('si');
const fbBtns = document.querySelectorAll('.fb-btn');
const cards  = document.querySelectorAll('.mc');
const noMods = document.getElementById('noMods');
let filt = 'all';
function doFilter() {
  const q = (si?si.value:'').toLowerCase().trim();
  let vis = 0;
  cards.forEach(c => {
    const m = (filt==='all'||(c.dataset.type||'').includes(filt)) && (!q||(c.dataset.name||'').includes(q)||(c.dataset.type||'').includes(q)||(c.dataset.desc||'').includes(q)||(c.dataset.tags||'').includes(q));
    c.style.display = m ? '' : 'none'; if(m) vis++;
  });
  if (noMods) noMods.style.display = vis===0?'block':'none';
}
window.filterMods = doFilter;
if (si) { si.addEventListener('input', doFilter); si.addEventListener('keydown', e=>{if(e.key==='Enter')doFilter();}); }
fbBtns.forEach(b=>b.addEventListener('click',()=>{fbBtns.forEach(x=>x.classList.remove('on'));b.classList.add('on');filt=b.dataset.filter||'all';doFilter();}));
document.querySelectorAll('.stag').forEach(t=>t.addEventListener('click',()=>{if(si){si.value=t.textContent.trim();doFilter();}document.getElementById('modsS')?.scrollIntoView({behavior:'smooth'});}));
document.querySelectorAll('.cc').forEach(c=>c.addEventListener('click',e=>{e.preventDefault();filt=c.dataset.filter||'all';fbBtns.forEach(b=>b.classList.toggle('on',b.dataset.filter===filt));doFilter();document.getElementById('modsS')?.scrollIntoView({behavior:'smooth',block:'start'});}));

// Pageview
(function(){const fd=new FormData();fd.append('type','pageview');fetch('stats.php',{method:'POST',body:fd}).catch(()=>{});})();

// Active nav
const secs=document.querySelectorAll('section[id]');
const nls=document.querySelectorAll('.nlinks a');
window.addEventListener('scroll',()=>{const y=scrollY+100;secs.forEach(s=>{if(y>=s.offsetTop&&y<s.offsetTop+s.offsetHeight)nls.forEach(a=>a.classList.toggle('on',a.getAttribute('href')===`#${s.id}`));});},{passive:true});

// Intersection observer
const io=new IntersectionObserver(en=>{en.forEach(e=>{if(e.isIntersecting){e.target.classList.add('fi');io.unobserve(e.target);}});},{threshold:.1});
document.querySelectorAll('.mc,.ac2,.cc').forEach(el=>io.observe(el));
